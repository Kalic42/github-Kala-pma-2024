package com.example.strongerme

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class DifficultySelectionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_difficulty_selection)

        val sharedPrefs = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        val isRegistered = sharedPrefs.getBoolean("isRegistered", false)
        //sharedPrefs.edit().apply {
        //    putBoolean("isRegistered", false) // Resetujeme na false
        //    apply() // Uložíme změny
        //}
        if (!isRegistered) {
            val intent = Intent(this, RegistrationActivity::class.java)
            startActivity(intent)
            finish()
        }


        // Najdeme tlačítka podle jejich ID
        val btnEasy = findViewById<Button>(R.id.btnEasy)
        val btnMedium = findViewById<Button>(R.id.btnMedium)
        val btnHard = findViewById<Button>(R.id.btnHard)

        // Nastavíme jednotlivé posluchače
        btnEasy.setOnClickListener {
            navigateToExercisePlan("easy")
        }

        btnMedium.setOnClickListener {
            navigateToExercisePlan("medium")
        }

        btnHard.setOnClickListener {
            navigateToExercisePlan("hard")
        }
    }

    // Navigace do ExercisePlanActivity
    private fun navigateToExercisePlan(difficulty: String) {
        Log.d("DifficultySelection", "Selected difficulty: $difficulty")

        // Uložení obtížnosti
        saveDifficulty(difficulty)

        // Přechod na další aktivitu
        val intent = Intent(this, ExercisePlanActivity::class.java).apply {
            putExtra("difficulty", difficulty)
        }
        startActivity(intent)
        finish()
    }

    // Uložení obtížnosti do SharedPreferences
    private fun saveDifficulty(difficulty: String) {
        val sharedPrefs = getSharedPreferences("UserPrefs", MODE_PRIVATE)
        sharedPrefs.edit().apply {
            putString("difficulty", difficulty) // Uložíme klíč "difficulty" s hodnotou
            apply() // Potvrdíme změny
        }
    }
}
