package com.example.strongerme

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ExercisePlanActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exercise_plan)

        // Získání RecyclerView z layoutu
        val rvExercises = findViewById<RecyclerView>(R.id.rvExercises)

        // Načtení obtížnosti z intentu
        val difficulty = intent.getStringExtra("difficulty") ?: "easy"

        // Získání cviků pro zvolenou obtížnost
        val exercises = getExercisesForDifficulty(difficulty)

        // Nastavení RecyclerView
        rvExercises.layoutManager = LinearLayoutManager(this)
        rvExercises.adapter = ExerciseAdapter(exercises) // Naplnění RecyclerView
    }

    // Metoda pro generování cviků
    private fun getExercisesForDifficulty(difficulty: String): List<Exercise> {
        return when (difficulty) {
            "easy" -> listOf(
                Exercise("Dřepy", "Proveďte základní dřepy pro zahřátí", 2),
                Exercise("Kliky", "Proveďte kliky pro posílení horní části těla", 2),
                Exercise("Plank", "Zůstaňte v pozici plank pro zpevnění středu těla", 2)
            )
            "medium" -> listOf(
                Exercise("Dřepy", "Proveďte dřepy s posílením", 2),
                Exercise("Kliky", "Proveďte kliky s těžší technikou", 2),
                Exercise("Plank", "Udržujte pozici plank po dobu delší", 2),
                Exercise("Výpady", "Výpady s většími pohyby", 2),
                Exercise("Mountain Climbers", "Proveďte Mountain Climbers", 2),
                Exercise("Jumping Jacks", "Skákejte s ruce i nohama", 2)
            )
            "hard" -> listOf(
                Exercise("Dřepy s váhou", "Přidejte váhu pro náročnější dřepy", 2),
                Exercise("Kliky s nohama zvednutýma", "Provádějte kliky s nohama zvednutýma", 2),
                Exercise("Plank s nohama zvednutýma", "Udržujte plank s nohama zvednutýma", 2),
                Exercise("Burpees", "Maximální intenzita Burpees", 2),
                Exercise("Skákání přes švihadlo", "Skákání přes švihadlo s rychlým tempem", 2),
                Exercise("Pull-ups", "Proveďte pull-upy na hrazdě", 2),
                Exercise("Squat Jumps", "Skákání do dřepu", 2),
                Exercise("Push-ups", "Provádějte push-upy na plný rozsah", 2),
                Exercise("Dřepy s výskokem", "Skákejte po každém dřepu", 2)
            )
            else -> emptyList()
        }
    }
}
