package com.example.strongerme

data class Exercise(
    val name: String,          // Název cviku
    val description: String,   // Popis cviku
    val duration: Int          // Délka cviku v minutách
)
