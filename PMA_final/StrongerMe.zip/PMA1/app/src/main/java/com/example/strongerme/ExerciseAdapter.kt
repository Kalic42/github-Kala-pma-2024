package com.example.strongerme

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// Tento adapter zobrazuje seznam cvičení
class ExerciseAdapter(private val exercises: List<Exercise>) : RecyclerView.Adapter<ExerciseAdapter.ExerciseViewHolder>() {

    // Vytvoření view holderu pro každou položku v seznamu
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExerciseViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_exercise, parent, false)
        return ExerciseViewHolder(itemView)
    }

    // Naplňujeme data do jednotlivých položek
    override fun onBindViewHolder(holder: ExerciseViewHolder, position: Int) {
        val currentExercise = exercises[position]
        holder.exerciseName.text = currentExercise.name
        holder.exerciseDescription.text = currentExercise.description
    }

    // Vrací počet položek v seznamu
    override fun getItemCount(): Int {
        return exercises.size
    }

    // ViewHolder pro jednotlivé položky seznamu
    class ExerciseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val exerciseName: TextView = itemView.findViewById(R.id.tvExerciseName)
        val exerciseDescription: TextView = itemView.findViewById(R.id.tvExerciseDescription)
    }
}
